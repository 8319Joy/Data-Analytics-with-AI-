// This is a utility function to parse CSV data
export async function parseCSV(file: File): Promise<any[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()

    reader.onload = (event) => {
      try {
        const csv = event.target?.result as string
        const lines = csv.split("\n")
        const headers = lines[0].split(",").map((header) => header.trim())

        const result = []

        for (let i = 1; i < lines.length; i++) {
          if (lines[i].trim() === "") continue

          const values = lines[i].split(",").map((value) => value.trim())
          const entry = {}

          headers.forEach((header, index) => {
            // Try to convert to number if possible
            const value = values[index]
            entry[header] = isNaN(Number(value)) ? value : Number(value)
          })

          result.push(entry)
        }

        resolve(result)
      } catch (error) {
        reject(error)
      }
    }

    reader.onerror = (error) => {
      reject(error)
    }

    reader.readAsText(file)
  })
}

// This is a utility function to parse Excel data
// In a real application, you would use a library like xlsx or exceljs
export async function parseExcel(file: File): Promise<any[]> {
  // This is a placeholder - in a real app you would use a proper Excel parsing library
  return new Promise((resolve, reject) => {
    // Simulate parsing
    setTimeout(() => {
      resolve([
        { month: "Jan", electronics: 4000, clothing: 2400, furniture: 2400 },
        { month: "Feb", electronics: 3000, clothing: 1398, furniture: 2210 },
        { month: "Mar", electronics: 2000, clothing: 9800, furniture: 2290 },
        { month: "Apr", electronics: 2780, clothing: 3908, furniture: 2000 },
        { month: "May", electronics: 1890, clothing: 4800, furniture: 2181 },
        { month: "Jun", electronics: 2390, clothing: 3800, furniture: 2500 },
      ])
    }, 1000)
  })
}
