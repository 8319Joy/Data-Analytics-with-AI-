"use client"

import { useState } from "react"
import { ChevronDown, Download } from "lucide-react"

import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

// Sample data - this would come from the CSV in a real application
const data = [
  { id: 1, date: "2023-01-15", product: "Laptop", category: "Electronics", price: 1299, quantity: 5, total: 6495 },
  { id: 2, date: "2023-01-16", product: "T-shirt", category: "Clothing", price: 25, quantity: 20, total: 500 },
  { id: 3, date: "2023-01-18", product: "Sofa", category: "Furniture", price: 899, quantity: 2, total: 1798 },
  { id: 4, date: "2023-01-20", product: "Smartphone", category: "Electronics", price: 899, quantity: 10, total: 8990 },
  { id: 5, date: "2023-01-22", product: "Jeans", category: "Clothing", price: 45, quantity: 15, total: 675 },
  { id: 6, date: "2023-01-25", product: "Coffee Table", category: "Furniture", price: 199, quantity: 5, total: 995 },
  { id: 7, date: "2023-01-27", product: "Headphones", category: "Electronics", price: 149, quantity: 8, total: 1192 },
  { id: 8, date: "2023-01-30", product: "Dress", category: "Clothing", price: 65, quantity: 12, total: 780 },
  { id: 9, date: "2023-02-02", product: "Bookshelf", category: "Furniture", price: 129, quantity: 3, total: 387 },
  { id: 10, date: "2023-02-05", product: "Tablet", category: "Electronics", price: 499, quantity: 7, total: 3493 },
]

export function DataTable() {
  const [searchTerm, setSearchTerm] = useState("")

  const filteredData = data.filter((item) =>
    Object.values(item).some((value) => value.toString().toLowerCase().includes(searchTerm.toLowerCase())),
  )

  return (
    <div className="w-full">
      <div className="flex items-center justify-between py-4">
        <Input
          placeholder="Search..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="max-w-sm"
        />
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="outline"
              className="ml-auto border-purple-300 text-purple-700 hover:bg-purple-50 dark:border-purple-700 dark:text-purple-300 dark:hover:bg-purple-950"
            >
              <Download className="mr-2 h-4 w-4" />
              Export
              <ChevronDown className="ml-2 h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>Export Options</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem>Export as CSV</DropdownMenuItem>
            <DropdownMenuItem>Export as Excel</DropdownMenuItem>
            <DropdownMenuItem>Export as PDF</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
      <div className="rounded-md border border-purple-200 dark:border-purple-800 bg-white/70 backdrop-blur-md dark:bg-slate-900/70">
        <Table>
          <TableHeader className="bg-purple-50 dark:bg-purple-950">
            <TableRow>
              <TableHead className="w-[100px] text-purple-700 dark:text-purple-300">ID</TableHead>
              <TableHead className="text-pink-700 dark:text-pink-300">Date</TableHead>
              <TableHead className="text-blue-700 dark:text-blue-300">Product</TableHead>
              <TableHead className="text-green-700 dark:text-green-300">Category</TableHead>
              <TableHead className="text-amber-700 dark:text-amber-300 text-right">Price</TableHead>
              <TableHead className="text-teal-700 dark:text-teal-300 text-right">Quantity</TableHead>
              <TableHead className="text-purple-700 dark:text-purple-300 text-right">Total</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredData.map((row, index) => (
              <TableRow
                key={row.id}
                className={
                  index % 2 === 0 ? "bg-white/50 dark:bg-slate-900/50" : "bg-purple-50/50 dark:bg-purple-950/50"
                }
              >
                <TableCell className="font-medium">{row.id}</TableCell>
                <TableCell>{row.date}</TableCell>
                <TableCell>{row.product}</TableCell>
                <TableCell>{row.category}</TableCell>
                <TableCell className="text-right">${row.price.toFixed(2)}</TableCell>
                <TableCell className="text-right">{row.quantity}</TableCell>
                <TableCell className="text-right">${row.total.toFixed(2)}</TableCell>
              </TableRow>
            ))}
            {filteredData.length === 0 && (
              <TableRow>
                <TableCell colSpan={7} className="h-24 text-center">
                  No results found.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
