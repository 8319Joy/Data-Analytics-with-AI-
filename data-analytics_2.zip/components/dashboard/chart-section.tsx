"use client"

import { BarChart, LineChart, PieChart } from "lucide-react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { SalesBarChart } from "@/components/charts/sales-bar-chart"
import { SalesLineChart } from "@/components/charts/sales-line-chart"
import { SalesPieChart } from "@/components/charts/sales-pie-chart"

export function ChartSection() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="border-purple-200 bg-white/50 backdrop-blur-sm dark:border-purple-800 dark:bg-slate-900/50">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-purple-700 dark:text-purple-300">Total Revenue</CardTitle>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              className="h-4 w-4 text-purple-500"
            >
              <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
            </svg>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-700 dark:text-purple-300">$45,231.89</div>
            <p className="text-xs text-purple-600 dark:text-purple-400">+20.1% from last month</p>
          </CardContent>
        </Card>
        <Card className="border-pink-200 bg-white/50 backdrop-blur-sm dark:border-pink-800 dark:bg-slate-900/50">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-pink-700 dark:text-pink-300">Sales</CardTitle>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              className="h-4 w-4 text-pink-500"
            >
              <rect width="20" height="14" x="2" y="5" rx="2" />
              <path d="M2 10h20" />
            </svg>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-pink-700 dark:text-pink-300">+12,234</div>
            <p className="text-xs text-pink-600 dark:text-pink-400">+19% from last month</p>
          </CardContent>
        </Card>
        <Card className="border-blue-200 bg-white/50 backdrop-blur-sm dark:border-blue-800 dark:bg-slate-900/50">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-blue-700 dark:text-blue-300">Active Users</CardTitle>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              className="h-4 w-4 text-blue-500"
            >
              <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
            </svg>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-700 dark:text-blue-300">+573</div>
            <p className="text-xs text-blue-600 dark:text-blue-400">+201 since last hour</p>
          </CardContent>
        </Card>
        <Card className="border-green-200 bg-white/50 backdrop-blur-sm dark:border-green-800 dark:bg-slate-900/50">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-green-700 dark:text-green-300">Conversion Rate</CardTitle>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth="2"
              className="h-4 w-4 text-green-500"
            >
              <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
            </svg>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-700 dark:text-green-300">3.2%</div>
            <p className="text-xs text-green-600 dark:text-green-400">+0.1% from last week</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="bar" className="w-full">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Sales Performance</h2>
          <TabsList className="bg-white/50 backdrop-blur-sm dark:bg-slate-900/50 p-1 rounded-lg">
            <TabsTrigger
              value="bar"
              className="data-[state=active]:bg-purple-100 data-[state=active]:text-purple-700 dark:data-[state=active]:bg-purple-900 dark:data-[state=active]:text-purple-300"
            >
              <BarChart className="h-4 w-4 mr-2" />
              Bar
            </TabsTrigger>
            <TabsTrigger
              value="line"
              className="data-[state=active]:bg-pink-100 data-[state=active]:text-pink-700 dark:data-[state=active]:bg-pink-900 dark:data-[state=active]:text-pink-300"
            >
              <LineChart className="h-4 w-4 mr-2" />
              Line
            </TabsTrigger>
            <TabsTrigger
              value="pie"
              className="data-[state=active]:bg-blue-100 data-[state=active]:text-blue-700 dark:data-[state=active]:bg-blue-900 dark:data-[state=active]:text-blue-300"
            >
              <PieChart className="h-4 w-4 mr-2" />
              Pie
            </TabsTrigger>
          </TabsList>
        </div>

        <Card className="border-none bg-white/70 backdrop-blur-md shadow-xl dark:bg-slate-900/70">
          <TabsContent value="bar">
            <CardHeader>
              <CardTitle>Monthly Sales</CardTitle>
              <CardDescription>Comparison of monthly sales data across different product categories.</CardDescription>
            </CardHeader>
            <CardContent className="pl-2">
              <SalesBarChart />
            </CardContent>
          </TabsContent>

          <TabsContent value="line">
            <CardHeader>
              <CardTitle>Sales Trends</CardTitle>
              <CardDescription>Sales performance trends over the past 12 months.</CardDescription>
            </CardHeader>
            <CardContent className="pl-2">
              <SalesLineChart />
            </CardContent>
          </TabsContent>

          <TabsContent value="pie">
            <CardHeader>
              <CardTitle>Sales Distribution</CardTitle>
              <CardDescription>Distribution of sales across different product categories.</CardDescription>
            </CardHeader>
            <CardContent className="pl-2">
              <SalesPieChart />
            </CardContent>
          </TabsContent>
        </Card>
      </Tabs>
    </div>
  )
}
