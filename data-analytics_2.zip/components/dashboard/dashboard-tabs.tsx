"use client"

import { useState } from "react"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ChartSection } from "@/components/dashboard/chart-section"
import { DataTable } from "@/components/dashboard/data-table"
import { ThreeDVisualization } from "@/components/dashboard/three-d-visualization"

export function DashboardTabs() {
  const [activeTab, setActiveTab] = useState("charts")

  return (
    <Tabs defaultValue="charts" className="w-full" onValueChange={setActiveTab}>
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 bg-clip-text text-transparent">
          Sales Data Analysis
        </h1>
        <TabsList className="bg-white/50 backdrop-blur-sm dark:bg-slate-900/50 p-1 rounded-lg">
          <TabsTrigger
            value="charts"
            className="data-[state=active]:bg-purple-100 data-[state=active]:text-purple-700 dark:data-[state=active]:bg-purple-900 dark:data-[state=active]:text-purple-300"
          >
            Charts
          </TabsTrigger>
          <TabsTrigger
            value="3d"
            className="data-[state=active]:bg-pink-100 data-[state=active]:text-pink-700 dark:data-[state=active]:bg-pink-900 dark:data-[state=active]:text-pink-300"
          >
            3D Visualization
          </TabsTrigger>
          <TabsTrigger
            value="data"
            className="data-[state=active]:bg-blue-100 data-[state=active]:text-blue-700 dark:data-[state=active]:bg-blue-900 dark:data-[state=active]:text-blue-300"
          >
            Raw Data
          </TabsTrigger>
        </TabsList>
      </div>

      <TabsContent value="charts" className="space-y-6">
        <ChartSection />
      </TabsContent>

      <TabsContent value="3d">
        <ThreeDVisualization />
      </TabsContent>

      <TabsContent value="data">
        <DataTable />
      </TabsContent>
    </Tabs>
  )
}
