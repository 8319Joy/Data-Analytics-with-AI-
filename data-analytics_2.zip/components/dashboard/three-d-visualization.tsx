"use client"

import { useRef, useState } from "react"
import { Canvas, useFrame } from "@react-three/fiber"
import { OrbitControls, Text, Environment } from "@react-three/drei"
import * as THREE from "three"

// Sample data - this would come from the CSV in a real application
const data = [
  { category: "Electronics", sales: 400, profit: 120 },
  { category: "Clothing", sales: 300, profit: 90 },
  { category: "Furniture", sales: 200, profit: 50 },
  { category: "Books", sales: 100, profit: 30 },
  { category: "Other", sales: 150, profit: 45 },
]

const colors = [
  "#8b5cf6", // Purple
  "#ec4899", // Pink
  "#3b82f6", // Blue
  "#10b981", // Green
  "#f59e0b", // Amber
]

function Bar({ position, height, width = 1, depth = 1, color, label, value }) {
  const meshRef = useRef()
  const [hovered, setHovered] = useState(false)
  const [clicked, setClicked] = useState(false)

  useFrame(() => {
    if (meshRef.current) {
      // Animate the bar height
      meshRef.current.scale.y = THREE.MathUtils.lerp(meshRef.current.scale.y, clicked ? height * 1.2 : height, 0.1)

      // Add a subtle hover effect
      if (hovered) {
        meshRef.current.scale.x = 1 + Math.sin(Date.now() * 0.01) * 0.05
        meshRef.current.scale.z = 1 + Math.sin(Date.now() * 0.01) * 0.05
      } else {
        meshRef.current.scale.x = THREE.MathUtils.lerp(meshRef.current.scale.x, width, 0.1)
        meshRef.current.scale.z = THREE.MathUtils.lerp(meshRef.current.scale.z, depth, 0.1)
      }
    }
  })

  return (
    <group position={position}>
      <mesh
        ref={meshRef}
        scale={[width, 0.1, depth]}
        position={[0, height / 2, 0]}
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
        onPointerDown={() => setClicked(!clicked)}
        castShadow
        receiveShadow
      >
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial
          color={color}
          metalness={0.3}
          roughness={0.4}
          emissive={hovered ? color : "#000000"}
          emissiveIntensity={hovered ? 0.5 : 0}
        />
      </mesh>
      <Text position={[0, height + 0.3, 0]} fontSize={0.3} color="white" anchorX="center" anchorY="bottom">
        {label}
      </Text>
      <Text
        position={[0, height + 0.7, 0]}
        fontSize={0.25}
        color={hovered ? "white" : "#aaaaaa"}
        anchorX="center"
        anchorY="bottom"
      >
        {value}
      </Text>
    </group>
  )
}

function BarChart3D() {
  const maxValue = Math.max(...data.map((item) => item.sales))
  const spacing = 1.5

  return (
    <>
      {data.map((item, index) => {
        const normalizedHeight = (item.sales / maxValue) * 5
        return (
          <Bar
            key={index}
            position={[(index - data.length / 2) * spacing, 0, 0]}
            height={normalizedHeight}
            color={colors[index % colors.length]}
            label={item.category}
            value={`$${item.sales}`}
          />
        )
      })}

      {/* Grid */}
      <gridHelper args={[20, 20, "#444444", "#222222"]} position={[0, 0, 0]} />

      {/* Axes labels */}
      <Text position={[0, 6, 0]} fontSize={0.5} color="white" anchorX="center" anchorY="bottom">
        Sales ($)
      </Text>
      <Text position={[0, 0, -8]} fontSize={0.5} color="white" anchorX="center" anchorY="bottom">
        Categories
      </Text>
    </>
  )
}

export function ThreeDVisualization() {
  return (
    <div className="w-full h-[600px] rounded-lg overflow-hidden border bg-gradient-to-br from-purple-900 to-blue-900">
      <Canvas shadows camera={{ position: [0, 5, 10], fov: 50 }} gl={{ antialias: true }}>
        <color attach="background" args={["#111827"]} />
        <ambientLight intensity={0.5} />
        <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} intensity={1} castShadow />
        <pointLight position={[-10, -10, -10]} color="#ec4899" intensity={0.5} />

        <BarChart3D />

        <Environment preset="city" />
        <OrbitControls enablePan={true} enableZoom={true} enableRotate={true} minDistance={5} maxDistance={20} />
      </Canvas>
    </div>
  )
}
