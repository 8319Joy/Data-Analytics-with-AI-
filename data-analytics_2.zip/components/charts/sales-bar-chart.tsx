"use client"

import { Bar, BarChart, CartesianGrid, Legend, XAxis, YAxis } from "recharts"

import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

// Sample data - this would come from the CSV in a real application
const data = [
  { month: "Jan", electronics: 4000, clothing: 2400, furniture: 2400 },
  { month: "Feb", electronics: 3000, clothing: 1398, furniture: 2210 },
  { month: "Mar", electronics: 2000, clothing: 9800, furniture: 2290 },
  { month: "Apr", electronics: 2780, clothing: 3908, furniture: 2000 },
  { month: "May", electronics: 1890, clothing: 4800, furniture: 2181 },
  { month: "Jun", electronics: 2390, clothing: 3800, furniture: 2500 },
  { month: "Jul", electronics: 3490, clothing: 4300, furniture: 2100 },
]

export function SalesBarChart() {
  return (
    <ChartContainer
      config={{
        electronics: {
          label: "Electronics",
          color: "#8b5cf6", // Purple
        },
        clothing: {
          label: "Clothing",
          color: "#ec4899", // Pink
        },
        furniture: {
          label: "Furniture",
          color: "#3b82f6", // Blue
        },
      }}
      className="aspect-[4/3]"
    >
      <BarChart
        data={data}
        margin={{
          top: 20,
          right: 30,
          left: 20,
          bottom: 5,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="month" />
        <YAxis />
        <ChartTooltip content={<ChartTooltipContent />} />
        <Legend />
        <Bar dataKey="electronics" fill="var(--color-electronics)" radius={[4, 4, 0, 0]} />
        <Bar dataKey="clothing" fill="var(--color-clothing)" radius={[4, 4, 0, 0]} />
        <Bar dataKey="furniture" fill="var(--color-furniture)" radius={[4, 4, 0, 0]} />
      </BarChart>
    </ChartContainer>
  )
}
