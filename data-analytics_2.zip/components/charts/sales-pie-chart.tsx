"use client"

import { Cell, Legend, Pie, PieChart } from "recharts"

import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

// Sample data - this would come from the CSV in a real application
const data = [
  { name: "Electronics", value: 400 },
  { name: "Clothing", value: 300 },
  { name: "Furniture", value: 200 },
  { name: "Books", value: 100 },
  { name: "Other", value: 150 },
]

export function SalesPieChart() {
  return (
    <ChartContainer
      config={{
        Electronics: {
          label: "Electronics",
          color: "#8b5cf6", // Purple
        },
        Clothing: {
          label: "Clothing",
          color: "#ec4899", // Pink
        },
        Furniture: {
          label: "Furniture",
          color: "#3b82f6", // Blue
        },
        Books: {
          label: "Books",
          color: "#10b981", // Green
        },
        Other: {
          label: "Other",
          color: "#f59e0b", // Amber
        },
      }}
      className="aspect-[4/3]"
    >
      <PieChart
        margin={{
          top: 20,
          right: 30,
          left: 20,
          bottom: 5,
        }}
      >
        <Pie data={data} cx="50%" cy="50%" labelLine={false} outerRadius={80} fill="#8884d8" dataKey="value">
          {data.map((entry, index) => (
            <Cell key={`cell-${index}`} fill={`var(--color-${entry.name})`} />
          ))}
        </Pie>
        <ChartTooltip content={<ChartTooltipContent />} />
        <Legend />
      </PieChart>
    </ChartContainer>
  )
}
