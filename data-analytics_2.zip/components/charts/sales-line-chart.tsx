"use client"

import { CartesianGrid, Legend, Line, LineChart, XAxis, YAxis } from "recharts"

import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

// Sample data - this would come from the CSV in a real application
const data = [
  { month: "Jan", sales: 4000, target: 4500 },
  { month: "Feb", sales: 3000, target: 3500 },
  { month: "Mar", sales: 5000, target: 4500 },
  { month: "Apr", sales: 2780, target: 3000 },
  { month: "May", sales: 1890, target: 2000 },
  { month: "Jun", sales: 2390, target: 2500 },
  { month: "Jul", sales: 3490, target: 3000 },
  { month: "Aug", sales: 4000, target: 3500 },
  { month: "Sep", sales: 2780, target: 3000 },
  { month: "Oct", sales: 1890, target: 2000 },
  { month: "Nov", sales: 3490, target: 3000 },
  { month: "Dec", sales: 4000, target: 4500 },
]

export function SalesLineChart() {
  return (
    <ChartContainer
      config={{
        sales: {
          label: "Actual Sales",
          color: "#ec4899", // Pink
        },
        target: {
          label: "Target Sales",
          color: "#8b5cf6", // Purple
        },
      }}
      className="aspect-[4/3]"
    >
      <LineChart
        data={data}
        margin={{
          top: 20,
          right: 30,
          left: 20,
          bottom: 5,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="month" />
        <YAxis />
        <ChartTooltip content={<ChartTooltipContent />} />
        <Legend />
        <Line type="monotone" dataKey="sales" stroke="var(--color-sales)" activeDot={{ r: 8 }} strokeWidth={2} />
        <Line type="monotone" dataKey="target" stroke="var(--color-target)" strokeDasharray="5 5" strokeWidth={2} />
      </LineChart>
    </ChartContainer>
  )
}
