"use client"

import type React from "react"

import { useState } from "react"
import { FileSpreadsheet, Upload } from "lucide-react"
import { useRouter } from "next/navigation"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { toast } from "@/components/ui/use-toast"

export function FileUpload() {
  const [file, setFile] = useState<File | null>(null)
  const [uploading, setUploading] = useState(false)
  const [progress, setProgress] = useState(0)
  const router = useRouter()

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0]
    if (selectedFile) {
      // Check if file is CSV or Excel
      const fileType = selectedFile.type
      if (
        fileType === "text/csv" ||
        fileType === "application/vnd.ms-excel" ||
        fileType === "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      ) {
        setFile(selectedFile)
      } else {
        toast({
          title: "Invalid file type",
          description: "Please upload a CSV or Excel file.",
          variant: "destructive",
        })
      }
    }
  }

  const handleUpload = async () => {
    if (!file) return

    setUploading(true)

    // Simulate upload progress
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          return 100
        }
        return prev + 10
      })
    }, 300)

    try {
      // Simulate file processing
      await new Promise((resolve) => setTimeout(resolve, 3000))

      clearInterval(interval)
      setProgress(100)

      toast({
        title: "Upload successful",
        description: "Your file has been processed successfully.",
      })

      // Redirect to dashboard
      setTimeout(() => {
        router.push("/dashboard")
      }, 1000)
    } catch (error) {
      toast({
        title: "Upload failed",
        description: "There was an error uploading your file.",
        variant: "destructive",
      })
      setUploading(false)
      clearInterval(interval)
    }
  }

  return (
    <Card className="w-full">
      <CardContent className="pt-6">
        <div className="flex flex-col items-center">
          {!file ? (
            <>
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-r from-purple-100 to-pink-100 dark:from-purple-900 dark:to-pink-900">
                <FileSpreadsheet className="h-6 w-6 text-purple-600 dark:text-purple-400" />
              </div>
              <label
                htmlFor="file-upload"
                className="cursor-pointer rounded-md bg-white px-4 py-2 text-sm font-medium text-slate-900 shadow-sm ring-1 ring-inset ring-slate-300 hover:bg-slate-50 dark:bg-slate-800 dark:text-slate-200 dark:ring-slate-700 dark:hover:bg-slate-700"
              >
                <span>Select CSV or Excel file</span>
                <input
                  id="file-upload"
                  name="file-upload"
                  type="file"
                  className="sr-only"
                  accept=".csv,.xls,.xlsx"
                  onChange={handleFileChange}
                />
              </label>
              <p className="mt-2 text-xs text-slate-500 dark:text-slate-400">Supported formats: CSV, XLS, XLSX</p>
            </>
          ) : (
            <div className="w-full">
              <div className="mb-4 flex items-center justify-between">
                <div className="flex items-center">
                  <FileSpreadsheet className="mr-2 h-5 w-5 text-slate-600 dark:text-slate-400" />
                  <span className="text-sm font-medium">{file.name}</span>
                </div>
                <Button variant="ghost" size="sm" onClick={() => setFile(null)} disabled={uploading}>
                  Change
                </Button>
              </div>

              {uploading ? (
                <div className="space-y-2">
                  <Progress value={progress} className="h-2 w-full" />
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    {progress === 100 ? "Processing data..." : `Uploading: ${progress}%`}
                  </p>
                </div>
              ) : (
                <Button
                  onClick={handleUpload}
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
                >
                  <Upload className="mr-2 h-4 w-4" />
                  Upload and analyze
                </Button>
              )}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
