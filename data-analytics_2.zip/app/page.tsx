import { FileUpload } from "@/components/file-upload"
import { HeroSection } from "@/components/hero-section"

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-purple-50 via-pink-50 to-blue-50 dark:from-purple-950 dark:via-pink-950 dark:to-blue-950">
      <HeroSection />
      <div className="container mx-auto px-4 py-12">
        <div className="mx-auto max-w-3xl text-center">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Upload your data</h2>
          <p className="mt-4 text-lg text-slate-600 dark:text-slate-400">
            Upload your CSV or Excel file to automatically generate insightful charts and 3D visualizations.
          </p>
          <div className="mt-8">
            <FileUpload />
          </div>
        </div>
      </div>
    </main>
  )
}
